---
name: business-writer
description: >
  Draft, review, and improve professional business writing across all common formats —
  emails, proposals, research proposals, executive summaries, business letters, and
  stakeholder messages. Use this skill whenever someone asks to write, draft, rewrite,
  improve, critique, or review ANY piece of business communication, even casually phrased
  requests like "help me write an email to my manager", "make this proposal stronger",
  "review my executive summary", or "is this too wordy?". Also trigger when someone
  shares a draft and asks for feedback, or when the task involves persuasion, clarity,
  audience alignment, or professional tone. Always use this skill before producing or
  evaluating any business document — short or long.
---

# Business Writer Skill

This skill helps Claude draft, review, and improve business writing for teams and
individuals across all professional contexts.

---

## Step 1 — Detect the Mode

Before doing anything, identify which mode applies:

**DRAFT mode** — User wants Claude to write something from scratch or from a brief.
**REVIEW mode** — User shares existing writing and wants feedback or improvement.
**BOTH** — User wants a critique followed by a rewritten version.

If the mode is unclear, ask one short question: "Would you like me to draft this, review
what you have, or both?"

---

## Step 2 — Detect the Document Type

Identify which type of document is being requested or shared:

| Type | Examples |
|---|---|
| Email / stakeholder message | Internal updates, client emails, follow-ups |
| Business proposal | Project proposals, internal pitches, budget requests |
| Research proposal | Formal research plans requesting time/funding |
| Executive summary | One-page summaries of reports or proposals |
| Business letter | Formal letters to clients, partners, or stakeholders |
| General business writing | Reports, memos, instructions, other professional text |

If unclear, ask the user which type before proceeding.

---

## Step 3 — Gather Audience and Purpose (if drafting)

Before writing, identify:

1. **Who is the reader?** (executive, technical lead, client, regulator, team member)
2. **What does the reader care about?** (ROI, schedule, risk, usability, compliance)
3. **What is the single goal of this document?** (approval, information, action, update)
4. **What tone is appropriate?** (formal, professional-conversational, urgent, neutral)

If the user hasn't provided this, ask briefly. Do not ask more than two questions at once.

---

## Step 4 — Apply the Right Framework

Read the relevant section in `references/frameworks.md` for the document type before
writing or reviewing. Key frameworks by type:

- **Emails / stakeholder messages** → 7 C's + BLUF + Seven-Step Proofreading Checklist
- **Proposals** → AIDA + Proof, Aristotle's Three Appeals, Proposal Structure
- **Research proposals** → Research Proposal Structure + Customer Priority Alignment
- **Executive summaries** → Executive Summary Structure + BLUF + Mental Picture principle
- **Business letters** → Full-Block Format + AIDA or 7 C's depending on purpose
- **All persuasive writing** → Hot Buttons + Audience Alignment + 8S Framework (optional)

---

## Step 5 — Draft or Review

### When DRAFTING:

- Write a one-sentence objective before drafting (internal step, not shown to user unless helpful).
- Lead with the main point within the first 150 words (BLUF).
- Use active voice. Replace weak noun phrases with strong verbs ("decide" not "make a decision").
- Match depth and vocabulary to the reader type (executive = outcomes; technician = detail).
- Apply the 7 C's as a baseline: Complete, Concise, Considerate, Clear, Concrete, Courteous, Correct.
- End every persuasive document with one specific call to action (not "let me know your thoughts").

### When REVIEWING:

Run through this checklist and flag issues clearly:

1. **Purpose** — Is there a clear single objective? Is it stated early?
2. **Audience alignment** — Does the tone, depth, and vocabulary match the reader?
3. **BLUF** — Is the main point within the first 150 words?
4. **Conciseness** — Are there filler phrases, redundancies, or passive voice to cut?
5. **Concreteness** — Are vague claims backed by numbers, examples, or evidence?
6. **Courtesy and tone** — Does it feel professional and respectful?
7. **Call to action** — Is the next step clear and specific?
8. **Correctness** — Note any grammar, spelling, or factual issues observed.

Present feedback as: **What works**, then **What to improve**, then offer a revised version
if appropriate.

---

## Step 6 — Apply the Writing Process

For important documents, follow this sequence:

1. **Draft** — Capture ideas freely, don't edit yet.
2. **Revise** — Improve structure, logic, and argument.
3. **Edit** — Refine sentence-level clarity, tone, and word choice.
4. **Proofread** — Check grammar, spelling, names, numbers, and formatting.

For routine or short documents (internal emails, quick updates), a single pass is fine.
For high-stakes documents (client proposals, executive summaries, stakeholder letters),
apply all four steps and flag if anything looks incomplete.

---

## Output Format

- Match the format to the document type (letter uses full-block; email uses paragraphs + signature block).
- Use headings, bullets, and white space only when they aid scanning.
- Never use bullet points to soften a refusal or pad a response.
- For reviews, structure output as: **Feedback summary → Revised version**.
- Keep the revised version clean — do not annotate inline unless the user asks.

---

## Reference Files

For detailed frameworks and checklists, read:
- `references/frameworks.md` — All writing frameworks (7 C's, 8S, AIDA, BLUF, etc.)
- `references/document-types.md` — Structure guides for each document type

Read the relevant section before drafting or reviewing. Do not load everything at once —
read only what the task requires.
