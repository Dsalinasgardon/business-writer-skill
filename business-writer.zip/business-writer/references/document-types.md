# Document Type Structure Guides

## Table of Contents

1. Email / Stakeholder Message
2. Business Proposal
3. Research Proposal
4. Executive Summary
5. Business Letter (Full-Block Format)

---

## 1. Email / Stakeholder Message

**Standard structure:**

| Section | Purpose |
|---|---|
| Subject line | Specific; state topic and action needed (e.g., "Approval needed: Q3 budget by Friday") |
| Introduction paragraph | Context + purpose of message |
| Body paragraph(s) | Main update, information, or request |
| Closing paragraph | Summary + next step + forward-looking statement |
| Signature block | Name, title, company, email, phone |

**Key rules:**
- Apply BLUF — main point in the first 150 words.
- Treat stakeholder emails like formal business letters (structure, tone, and precision matter).
- Never use casual habits (fragmented structure, no closing, no signature) for external stakeholders.
- Before sending: run the Seven-Step Email Proofreading Checklist.

---

## 2. Business Proposal

**Structure (organized around reader questions):**

| Section | Reader's question |
|---|---|
| Introduction | What is this proposal about? |
| Background / Problem | Why is this needed now? |
| Proposed solution | What exactly are you recommending? |
| Method and procedure | How will this be done? |
| Schedule / Timeline | When will it happen? |
| Cost and resources | How much will it require? |
| Benefits and feasibility | Why is this worthwhile and realistic? |
| Conclusion / Call to action | Why should we approve this? |

**Key rules:**
- Define the problem before presenting the solution — urgency justifies the proposal.
- Break costs down by phase or task; never present only a lump sum.
- End with one specific CTA and deadline, not "let me know your thoughts."
- Apply AIDA + Proof and Aristotle's Three Appeals for persuasive force.
- Apply the Mental Picture principle for clarity.
- Format: plain block-style, clear headings, white space for scanning.

**Common mistakes:**
- Starting with the solution before establishing the problem.
- Vague or lump-sum cost presentation.
- No clear timeline.
- Weak or missing conclusion.
- Features without benefits.

---

## 3. Research Proposal

**Structure:**

| Section | Purpose |
|---|---|
| Title | Clear identification of topic and focus |
| Introduction | Research topic + your organization's qualifications and strengths |
| Literature review | Prior research, existing knowledge, identified gaps |
| Objectives | Specific, measurable research goals |
| Methodology | How the research will be conducted (methods, data collection, tools) |
| Scope | What the project will AND will not accomplish |
| Timetable | Phases, milestones, and completion dates |
| Budget / Resource request | Personnel, equipment, materials, operational costs — itemized |

**Key rules:**
- A research proposal is both a research plan AND a persuasive document.
- Write from the customer's priorities — identify their selection criteria first.
- Highlight genuine organizational strengths that align with what the customer values.
- Every section must strengthen the case that your team is the right choice.
- Customer-focus test: *"As the customer reads this, will they recognize their own priorities in the document?"*

**Selection criteria to address:**
- Cost efficiency
- Schedule reliability
- Research quality and methodology
- Team experience and expertise
- Alignment with customer objectives

---

## 4. Executive Summary

**Standard structure:**

| Section | Content |
|---|---|
| Introduction | Issue + why it matters now (include one measurable cost, risk, or opportunity figure) |
| Need / Problem | What is wrong or missing; business impact |
| Proposed solution | Plain-language explanation of the recommendation |
| Evidence / Value proof | Strongest available data, outcomes, or prior results |
| Team qualifications | One differentiator — why your team is positioned to deliver |
| Conclusion + Action request | One specific approval request with deadline |

**Key rules:**
- Length: 5–10% of the full document, or one page maximum.
- BLUF is essential — the first sentence must communicate the core recommendation.
- Write from the decision-maker's perspective — lead with what they care about most.
- Create a clear mental picture — remove background that doesn't affect the decision.
- Every sentence should help the reader decide faster, not sound more complete.
- Avoid jargon; replace technical terms with plain-language alternatives where possible.

**Final review checklist:**
- Stays within one page
- All six sections present
- Strongest supporting evidence highlighted (not all evidence)
- Ends with one specific approval request and deadline
- Names, numbers, and grammar verified

---

## 5. Business Letter (Full-Block Format)

**Structure (all elements aligned to the left):**

| Element | Content |
|---|---|
| Sender address | Your name, title, organization, address |
| Date | Full date |
| Recipient address | Full name, title, organization, address |
| Salutation | "Dear Ms. [Last Name]:" (colon, not comma) |
| Introduction paragraph | Greeting + relationship context + purpose of letter |
| Body paragraph(s) | Main content: update, request, information, or argument |
| Conclusion paragraph | Summary + forward-looking statement + invitation for follow-up |
| Complimentary close | "Sincerely," or "Best regards," |
| Signature space | Handwritten signature (if printed) |
| Typed name + title | Your name and role |
| Enclosures (if any) | List documents included |

**For persuasive letters — apply AIDA + Proof:**
- Attention: Open with a striking fact, result, or short story.
- Interest/Desire: Explain value in 1–2 focused sentences.
- Proof: One piece of specific evidence (number, test result, outcome).
- Action: One direct request with deadline.

**Key rules:**
- Verify correct spelling of recipient's name and title before anything else.
- Include full contact details in the signature block every time.
- Use paragraphs — not bulleted blocks — for formal letters.
- Apply the Seven-Step Proofreading Checklist before sending.
- Professional emails to stakeholders follow the same standards as formal letters.
