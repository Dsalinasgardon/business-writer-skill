# Business Writing Frameworks Reference

## Table of Contents

1. The 7 C's
2. The 8S Framework
3. AIDA + Proof
4. BLUF
5. Aristotle's Three Appeals (Ethos / Logos / Pathos)
6. Hot Buttons and Audience Alignment
7. Jargon Control
8. Mental Picture Writing
9. Concise Writing / Paramedic Check
10. Seven-Step Email Proofreading Checklist
11. Five-Step Writing Routine

---

## 1. The 7 C's

The baseline standard for all business writing.

| C | Definition | Quick test |
|---|---|---|
| **Complete** | All needed information is included | Can reader decide without asking follow-up questions? |
| **Concise** | No unnecessary words | Can I cut anything without losing meaning? |
| **Considerate** | Written from reader's perspective | Does this address what the reader cares about? |
| **Clear** | Direct, precise, unambiguous | Is the main point immediately obvious? |
| **Concrete** | Specific facts, numbers, evidence | Are all claims backed by data or examples? |
| **Courteous** | Respectful and professional tone | Does this sound diplomatic, not cold or demanding? |
| **Correct** | Accurate grammar, spelling, facts | Are names, numbers, and language error-free? |

---

## 2. The 8S Framework

Eight qualities that make writing more persuasive and memorable. Use selectively — not every document needs all eight. Apply the ones that fit the context.

| S | Core idea | How to apply |
|---|---|---|
| **Simple** | Short sentences, active voice, clear words | Remove unnecessary clauses; prefer plain language |
| **Specific** | Concrete, vivid details | Replace vague nouns with precise descriptions |
| **Surprising** | Unexpected fact or angle | Add a striking statistic or counterintuitive insight |
| **Stirring** | Emotionally meaningful language | Choose words with energy over neutral alternatives |
| **Seductive** | Create curiosity and anticipation | Open with a question or hint at valuable information |
| **Smart** | Fresh insight or "aha" moment | Present a new perspective or reveal a hidden connection |
| **Social** | Personal, conversational tone | Use "you"; write like a human, not a policy document |
| **Story-Driven** | Narrative structure | Include a brief before/during/after arc when relevant |

---

## 3. AIDA + Proof

Use for proposals, persuasive emails, business letters requesting action, and pitches.

**A — Attention (Hook)**
- Open with a bold claim, striking fact, relevant result, or short story.
- Identify the reader's "hot button" first — their biggest concern, fear, or opportunity.
- Example: *"Our process reduced processing time by 35% in two months."*

**I — Interest (Keep them reading)**
- Show understanding of the reader's situation.
- Use relevant examples; align with their priorities, not yours.
- Example: *"In similar organizations, this approach reduced onboarding time by 40%."*

**D — Desire (Build motivation)**
- Translate features into benefits and outcomes.
- Instead of "this tool improves efficiency" → "this tool frees your team from repetitive tasks so they can focus on strategic work."
- Connect to pain points, goals, or ambitions.

**A — Action (Clear next step)**
- One specific, direct request with a deadline.
- Example: *"Please approve the pilot by Friday so implementation can begin Monday."*
- Avoid: *"Let me know your thoughts."*

**+ Proof**
- Support claims with numbers, test results, testimonials, or verified outcomes.
- Example: *"Pilot testing showed a 28% reduction in processing errors over 60 days."*

---

## 4. BLUF (Bottom Line Up Front)

Use for emails, status updates, and any document where the reader needs to act quickly.

**Core principle:** State the conclusion, recommendation, or key fact in the first sentence. Context and details follow.

**Structure:**
1. Bottom line (decision, recommendation, or key fact)
2. Supporting context
3. Call to action or next step (if needed)

**Status update format:** Yes/no + outcome + link, or: No + ETA.

**Test:** Can the first sentence stand alone as a complete message? If yes, the BLUF is working.

---

## 5. Aristotle's Three Appeals

Use for proposals, executive summaries, and any high-stakes persuasive document.

| Appeal | What it answers | How to apply |
|---|---|---|
| **Ethos** (credibility) | "Can I trust you?" | Accurate data, cited sources, polished writing, relevant experience |
| **Logos** (logic) | "Does this make sense?" | Evidence, cost-benefit reasoning, measurable outcomes, option comparisons |
| **Pathos** (emotion) | "Why should I care?" | Consequences of inaction, urgency, success stories, connection to reader's real concerns |

All three work together. Logic alone rarely wins approval. Emotion without evidence loses credibility. Credibility without relevance gets ignored.

---

## 6. Hot Buttons and Audience Alignment

A "hot button" is the concern, goal, or fear that most influences a stakeholder's decisions.

**Common hot buttons by reader type:**

| Reader | Hot buttons | How to write for them |
|---|---|---|
| Executive | ROI, risk, speed, brand reputation | Lead with cost-benefit numbers; show how the plan protects strategy |
| Project manager | Schedule, resources, accountability | State exact timelines, owners, contingency plans |
| Engineer / technician | Technical validity, data accuracy | Provide specs, test results, standards |
| End-user / customer | Usability, reliability, support | Show practical benefits and after-implementation support |
| Regulator / compliance | Safety, legal standards | Lead with compliance alignment |

**Quick test for hot buttons:** If removing a detail would make the stakeholder hesitate or say "prove it," that detail is likely one of their hot buttons.

**Audience research questions:**
- What does the reader already know?
- What concerns them most?
- What do they need to decide?
- What vocabulary and tone do they expect?

---

## 7. Jargon Control

**Keep** technical terms when:
- They are the precise, standard industry name.
- Replacing them would create ambiguity.

**Replace** jargon when:
- A plain alternative exists and is equally accurate.
- The audience includes non-specialists.

**Define** terms when first introduced:
- Write full term, then abbreviation in parentheses.
- Example: *"Failure Mode Effects Analysis (FMEA)"* → use FMEA after.

**Never** define common words. **Never** include glossary entries for terms not used in the document.

**3-step jargon check:**
1. Scan for terms a non-expert would not understand.
2. Replace or define each one.
3. Read aloud — does anything still feel unnecessarily complex?

---

## 8. Mental Picture Writing

Help readers visualize ideas rather than process abstractions.

**Techniques:**
- **Metaphor:** *"Reliable as an old Nokia phone."* (not just "reliable")
- **Concrete numbers:** *"117 customers completed the program in 30 days."* (not "many customers")
- **Recast percentages as counts:** *"15 out of every 100 users leave after week one."* (not "15% churn")
- **Before/after framing:** Show the contrast between the problem state and the improved state.
- **Visuals:** Suggest charts, icons, or progress bars when data needs to communicate magnitude quickly.

**Test:** Read each key claim and ask — can the reader picture this? If not, make it more concrete.

---

## 9. Concise Writing / Paramedic Check

**Common filler to cut:**

| Cut | Replace with |
|---|---|
| in order to | to |
| due to the fact that | because |
| at this point in time | now |
| for the purpose of | for |
| make a decision | decide |
| conduct an analysis | analyze |

**Paramedic Check (for editing a wordy sentence):**
1. Circle prepositions (of, in, for, about) — too many signals wordiness.
2. Box "to be" verbs (is, are, was, were) — often hiding a stronger verb.
3. Find the real action — what is actually happening?
4. Turn that action into a verb.
5. Put the doer first.
6. Delete wind-up phrases ("The purpose of this report is to…").
7. Remove redundancies (free gift → gift; future plans → plans).

**Target:** After editing, try to cut 15–20% of total word count without losing meaning.

---

## 10. Seven-Step Email Proofreading Checklist

Use before sending any important email or stakeholder message.

| Step | Action | Why |
|---|---|---|
| 1. Names | Double-check spelling of recipient's name and organization | A misspelled name signals you don't pay attention |
| 2. Tone | Read as the recipient; rewrite anything cold, hostile, or demanding | Tone inconsistencies create misinterpretation |
| 3. Context | Ask: does the reader have the same background I do? Fill gaps | Readers can't act without enough information |
| 4. Clarity | Replace vague pronouns; shorten long sentences | Clear sentences increase response rates |
| 5. Wordiness | Cut filler; replace weak adverbs with strong verbs | Lean sentences make key points stand out |
| 6. Mechanical | Scan for spelling, homonym errors, punctuation | Errors signal poor quality control |
| 7. Let it sit | For sensitive messages, wait before rereading | Distance catches emotional wording and clarity gaps |

---

## 11. Five-Step Writing Routine

Use as a general process for any important document.

1. **Draft fast** — Write without editing. Get ideas on the page.
2. **Check the 8S list** — Is the writing specific? Emotionally engaging? Does it create curiosity?
3. **Cut 15%** — Remove unnecessary words to increase clarity.
4. **Add hook and human touch** — Front-load the benefit; use "you"; add concrete examples.
5. **Read aloud and revise** — Listen for awkward phrasing, long sentences, confusing transitions.
